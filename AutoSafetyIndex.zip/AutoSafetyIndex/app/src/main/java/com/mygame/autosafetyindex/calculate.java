package com.mygame.autosafetyindex;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class calculate extends AppCompatActivity {
    private EditText plain_text_input;
    private EditText plain_text_input2;
    private EditText plain_text_input3;
    private EditText plain_text_input4;
    private EditText plain_text_input5;
    private EditText plain_text_input7;
    private TextView textView9;
    private Button button6;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculate);
        plain_text_input = (EditText) findViewById(R.id.plain_text_input);
        plain_text_input2 = (EditText) findViewById(R.id.plain_text_input2);
        plain_text_input3 = (EditText) findViewById(R.id.plain_text_input3);
        plain_text_input4 = (EditText) findViewById(R.id.plain_text_input4);
        plain_text_input5 = (EditText) findViewById(R.id.plain_text_input5);
        plain_text_input7  = (EditText) findViewById(R.id.plain_text_input7);
        textView9 = (TextView)  findViewById(R.id.textView9);
        button6 = (Button) findViewById(R.id.button6);
        button6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double p,px,py,pz,pq,pw,pe;
                String S1 = plain_text_input.getText().toString();
                String S2 = plain_text_input2.getText().toString();
                String S3 = plain_text_input3.getText().toString();
                String S4 = plain_text_input4.getText().toString();
                String S5 = plain_text_input5.getText().toString();
                String S6 = plain_text_input7.getText().toString();
                px = Double.parseDouble(S1);
                py = Double.parseDouble(S2);
                pz = Double.parseDouble(S3);
                pq = Double.parseDouble(S4);
                pw = Double.parseDouble(S5);
                pe = Double.parseDouble(S6);
                p = px+py+pz+pq+pw+pe;
                String S = Double.toString(p);
                textView9.setText(S);
            }
        });
    }
}